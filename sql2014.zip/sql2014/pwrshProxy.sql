USE [msdb]
GO

/****** Object:  ProxyAccount [pwrshProxy]    Script Date: 1/18/2017 5:10:21 PM ******/
EXEC msdb.dbo.sp_add_proxy @proxy_name=N'pwrshProxy',@credential_name=N'PwrshCredential', 
		@enabled=1
GO

EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'pwrshProxy', @subsystem_id=12
GO


