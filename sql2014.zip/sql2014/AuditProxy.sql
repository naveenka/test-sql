USE [msdb]
GO

/****** Object:  ProxyAccount [AuditProxy]    Script Date: 1/18/2017 5:10:53 PM ******/
EXEC msdb.dbo.sp_add_proxy @proxy_name=N'AuditProxy',@credential_name=N'AuditCredential', 
		@enabled=1
GO

EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'AuditProxy', @subsystem_id=12
GO


