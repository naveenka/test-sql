USE [msdb]
GO

/****** Object:  Job [syspolicy_check_schedule_dev]    Script Date: 1/18/2017 5:09:44 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 1/18/2017 5:09:44 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'syspolicy_check_schedule_dev', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'ISDDBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Verify that automation is enabled.]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Verify that automation is enabled.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (msdb.dbo.fn_syspolicy_is_automation_enabled() != 1)
        BEGIN
            RAISERROR(34022, 16, 1)
        END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete old records]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete old records', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE [MDW].[dbo].[DBBackups] WHERE CreateDate < DATEADD(dd, -21, GETDATE())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Some audit related checks.]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Some audit related checks.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'dir SQLSERVER:\SQLPolicy\01D019DTB\DEV\Policies | where { $_.ScheduleUid -eq "CC488C35-48AB-426B-9DFC-E58F1BF5BD80" } |  where { $_.Enabled -eq 1} | where {$_.AutomatedPolicyEvaluationMode -eq 4} | Invoke-PolicyEvaluation -AdHocPolicyEvaluationMode 2 -TargetServerName 01D019DTB\DEV', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL 2008 CAT I Policies]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL 2008 CAT I Policies', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2008 SQL Servers" -PolicyCategoryFilter "Category I" �EvalMode "Check"
', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL 2012 CAT I Policies]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL 2012 CAT I Policies', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2012 SQL Servers" -PolicyCategoryFilter "Category I" �EvalMode "Check"
', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL 2008 CAT II Policies]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL 2008 CAT II Policies', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2008 SQL Servers" -PolicyCategoryFilter "Category II" �EvalMode "Check"
', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL 2012 CAT II Policies]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL 2012 CAT II Policies', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2012 SQL Servers" -PolicyCategoryFilter "Category II" �EvalMode "Check"
', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL 2008 CAT III Policies]    Script Date: 1/18/2017 5:09:44 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL 2008 CAT III Policies', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2008 SQL Servers" -PolicyCategoryFilter "Category III" �EvalMode "Check"
', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL 2012 CAT III Policies]    Script Date: 1/18/2017 5:09:45 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL 2012 CAT III Policies', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2012 SQL Servers" -PolicyCategoryFilter "Category III" �EvalMode "Check"
', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL Server 2014 CAT II Policies]    Script Date: 1/18/2017 5:09:45 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL Server 2014 CAT II Policies', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2014 SQL Servers" -PolicyCategoryFilter "SQL 2014 Category II" �EvalMode "Check"', 
		@database_name=N'MDW', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Evaluate SQL Server 2014 CAT III Policies]    Script Date: 1/18/2017 5:09:45 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Evaluate SQL Server 2014 CAT III Policies', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'SL "R:\Audit\DEV"
.\EPM_EnterpriseEvaluation_412.ps1 -ConfigurationGroup "Dev 2014 SQL Servers" -PolicyCategoryFilter "SQL 2014 Category III" �EvalMode "Check"', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'pwrshProxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


